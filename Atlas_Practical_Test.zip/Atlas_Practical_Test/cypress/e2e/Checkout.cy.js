describe('TC-001 - Checkout', function () {

    //Use the cy.fixture() method to pull data from fixture file
    before(function () {
      cy.fixture('users2').then(function (data) {
        this.data = data;
      })

      cy.fixture('users').then(function (data2) {
        this.data2 = data2;
      })
    })
  
    it('TC-001 - Checkout', function () {
      
      //Test data declaration
      const firstnameraw = this.data2.firstname
      const lastnameraw = this.data2.lastname
      const fullname = `${firstnameraw} ${lastnameraw}`
      const uuid = () => Cypress._.random(0, 1e6)
      const id = uuid()

      //go to URL and verify if Customer registration page is displayed
      cy.visit('https://practicesoftwaretesting.com/#/auth/login')
      cy.url().should('include', '/auth/login')
      cy.get("app-login").should('exist')
     
      //Login
      cy.login({
        email: this.data.email,
        password: this.data.password,
      })

      //Navigate to home
      cy.get("a[data-test='nav-home']").click()
      
      //Click product then add to cart
      cy.get("[data-test='product-name']").contains('Combination Pliers').click()
      cy.get("#btn-add-to-cart").click()
      cy.wait(2000)
      cy.get("[data-test='nav-cart']").should('exist')

      //Checkout product
      cy.get("#lblCartCount").click()
      cy.wait(2000)
      cy.url().should('include', '/checkout')
      cy.get("[data-test='proceed-1']").click()
      cy.wait(1000)
      cy.get("[data-test='proceed-2']").click()
      cy.wait(1000)
      cy.get("[data-test='proceed-3']").click()
      cy.wait(1000)

      //Enter Payment Method
      cy.get("#payment-method")
      .select('Cash on Delivery', { force: true })
      cy.get("#account-name").type(fullname)
      cy.get("#account-number").type(id)
      cy.get("[data-test='finish']").click()

      //check if payment is successfull
      cy.get(".alert.alert-success").should('exist')

      //Navigate back to Home page
      cy.get("a[data-test='nav-home']").click()

    })
  })