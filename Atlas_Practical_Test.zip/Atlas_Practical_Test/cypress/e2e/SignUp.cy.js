describe('TC-001 - Invalid Sign up check required fields', function () {

  //Use the cy.fixture() method to pull data from fixture file
  before(function () {
    cy.fixture('users').then(function (data) {
      this.data = data;
    })
  })

  it('TC-001 - Invalid Sign up check required fields', function () {
    
    //test data declaration
    const uuid = () => Cypress._.random(0, 1e6)
    const id = uuid()
    const addressraw = this.data.address
    const addressfinal = `${id} ${addressraw}`
    const email = `atlastestemail_${id}@mailinator.com`
    const password = `password${id}`

    //go to URL and verify if Customer registration page is displayed
    cy.visit('https://practicesoftwaretesting.com/#/auth/register')
    cy.url().should('include', '/auth/register')
    cy.get("form[data-test='register-form']").should('exist')

    //Click on Register before filling out the form
    cy.get("button[data-test='register-submit']").click()
    
    //Verifying required fields error
    cy.get("div[data-test='first-name-error']").should('exist')
    cy.get("div[data-test='last-name-error']").should('exist')
    cy.get("div[data-test='dob-error']").should('exist')
    cy.get("div[data-test='address-error']").should('exist')
    cy.get("div[data-test='postcode-error']").should('exist')
    cy.get("div[data-test='city-error']").should('exist')
    cy.get("div[data-test='state-error']").should('exist')
    cy.get("div[data-test='country-error']").should('exist')
    cy.get("div[data-test='phone-error']").should('exist')
    cy.get("div[data-test='email-error']").should('exist')
    cy.get("div[data-test='password-error']").should('exist')

    //Filling out form with invalid DOB
    cy.get("#first_name").type(this.data.firstname)
    cy.get("#last_name").type(this.data.lastname)
    cy.get("input#dob").type(this.data.invaliddob)
    cy.get("#address").type(addressfinal)
    cy.get("#postcode").type(id)
    cy.get("#city").type(this.data.city)
    cy.get("#state").type(this.data.state)
    cy.get("#country")
      .select('Argentina', { force: true })
    cy.get("#phone").type(id)
    cy.get("#email").type(email)
    cy.get("#password").type(password)

    //Clicking Register and verifying DOB error
    cy.get("button[data-test='register-submit']").click()
    cy.get("div[data-test='register-error']").should('exist')

  })
})

describe('TC-002 - Sign Up User', function () {

  //Use the cy.fixture() method to pull data from fixture file
  before(function () {
    cy.fixture('users').then(function (data) {
      this.data = data;
    })
  })

  it('TC-002 - Sign Up User', function () {
    
    //test data declaration
    const uuid = () => Cypress._.random(0, 1e6)
    const id = uuid()
    const addressraw = this.data.address
    const addressfinal = `${id} ${addressraw}`
    const email = `atlastestemail_${id}@mailinator.com`
    const password = `password${id}`

    //go to URL and verify if Customer registration page is displayed
    cy.visit('https://practicesoftwaretesting.com/#/auth/register')
    cy.url().should('include', '/auth/register')
    cy.get("form[data-test='register-form']").should('exist')

    //Filling up the registration page
    cy.get("#first_name").type(this.data.firstname)
    cy.get("#last_name").type(this.data.lastname)
    cy.get("input#dob").type(this.data.dob)
    cy.get("#address").type(addressfinal)
    cy.get("#postcode").type(id)
    cy.get("#city").type(this.data.city)
    cy.get("#state").type(this.data.state)
    cy.get("#country")
      .select('Argentina', { force: true })
    cy.get("#phone").type(id)
    cy.get("#email").type(email)
    cy.get("#password").type(password)

    //Passing auto generated email/password to be used for login
    cy.writeFile('cypress/fixtures/users2.json', {email: email, password: password})

    //Complete registration and assert page is correct.
    cy.get("button[data-test='register-submit']").click()
    cy.url().should('include', 'auth/login')
    cy.get("app-login").should('exist')
   
  })
})