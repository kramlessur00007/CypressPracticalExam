describe('TC-001 - Login check required fields', function () {

    //Use the cy.fixture() method to pull data from fixture file
    before(function () {
      cy.fixture('users2').then(function (data) {
        this.data = data;
      })
    })
  
    it('TC-001 - Login check required fields', function () {
      
      //go to URL and verify if Customer registration page is displayed
      cy.visit('https://practicesoftwaretesting.com/#/auth/login')
      cy.url().should('include', '/auth/login')
      cy.get("app-login").should('exist')
     
      //Clicking Login without entering user/pass
      cy.get("input[data-test='login-submit']").click()

      //Checking required fields error
      cy.get("div[data-test='email-error']").should('exist')
      cy.get("div[data-test='password-error']").should('exist')

    })
  })

  describe('TC-002 - Login using invalid credentials', function () {

    //Use the cy.fixture() method to pull data from fixture file
    before(function () {
      cy.fixture('users2').then(function (data) {
        this.data = data;
      })
    })
  
    it('TC-002 - Login using invalid credentials', function () {
      
      //go to URL and verify if Customer registration page is displayed
      cy.visit('https://practicesoftwaretesting.com/#/auth/login')
      cy.url().should('include', '/auth/login')
      cy.get("app-login").should('exist')
     
      //Entering invalid credentials
      cy.get("#email").type(this.data.email)
      cy.get("#password").type("$#^%@$&@")

      //Clicking Login and verify Login Error
      cy.get("input[data-test='login-submit']").click()
      cy.get("div[data-test='login-error']").should('exist')

    })
  })

  describe('TC-003 - Login valid credentials', function () {

    //Use the cy.fixture() method to pull data from fixture file
    before(function () {
      cy.fixture('users2').then(function (data) {
        this.data = data;
      })
    })
  
    it('TC-003 - Login valid credentials', function () {
      
      //go to URL and verify if Customer registration page is displayed
      cy.visit('https://practicesoftwaretesting.com/#/auth/login')
      cy.url().should('include', '/auth/login')
      cy.get("app-login").should('exist')

      cy.login({
        email: this.data.email,
        password: this.data.password,
      })

      cy.logout()
     
    })
  })