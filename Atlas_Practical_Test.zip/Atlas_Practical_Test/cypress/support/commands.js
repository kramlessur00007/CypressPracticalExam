// ***********************************************
// This example commands.js shows you how to
// create various custom commands and overwrite
// existing commands.
//
// For more comprehensive examples of custom
// commands please read more here:
// https://on.cypress.io/custom-commands
// ***********************************************
//
//
// -- This is a parent command --
// Cypress.Commands.add('login', (email, password) => { ... })
//
//
// -- This is a child command --
// Cypress.Commands.add('drag', { prevSubject: 'element'}, (subject, options) => { ... })
//
//
// -- This is a dual command --
// Cypress.Commands.add('dismiss', { prevSubject: 'optional'}, (subject, options) => { ... })
//
//
// -- This will overwrite an existing command --
// Cypress.Commands.overwrite('visit', (originalFn, url, options) => { ... })

  
  export default function addCustomCommands() {
    Cypress.Commands.add('login', options => {
        const email = options.email
        const password = options.password
      
        cy.get("#email").type(email)
        cy.wait(1000)
        cy.get("#password").type(password)
        cy.get("input[data-test='login-submit']").click()
        cy.wait(5000)
        cy.url().should('include', '/account')
        cy.get("h1[data-test='page-title']").should('exist')
    
      })

      Cypress.Commands.add('logout', () => {
    
        cy.get("#user-menu").click()
        cy.get("[data-test='nav-sign-out']").click()
        cy.wait(5000)
        cy.url().should('include', '/auth/login')
        cy.get("app-login").should('exist')

      })
  }